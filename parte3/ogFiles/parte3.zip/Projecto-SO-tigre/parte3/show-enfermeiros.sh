hexdump -e '"| %i | %-17.100s| %-11.100s| %3i | %i |\n"' enfermeiros.dat
